<?php 

// ini_set('display_errors',1);

define('SHOPIFY_APP_SECRET', '9a364113193133cb0edfe5b52c375b460cd80a85d3901451cf3131f4700d5d56');

function verify_webhook($data, $hmac_header)
{
  $calculated_hmac = base64_encode(hash_hmac('sha256', $data, SHOPIFY_APP_SECRET, true));
  return hash_equals($hmac_header, $calculated_hmac);
}


$hmac_header = $_SERVER['HTTP_X_SHOPIFY_HMAC_SHA256'];
$data = file_get_contents('php://input');
$verified = verify_webhook($data, $hmac_header);
//error_log('Webhook verified: '.var_export($verified, true)); //check error.log to see the result


if($verified){

   $response = $data;
   $customer = json_decode($data, true);
   
   // assign email from shopify customer webhook
   $email = $customer['email'];

   $first_name = $customer['first_name'];
   $last_name = $customer['last_name'];

  /* if($customer['phone']){

      $phonecode = substr($customer['default_address']['phone'],0,2);
      if($phonecode == "+1"){
         $phone = substr($customer['default_address']['phone'], 2);
      }
      if(strlen($phone) != 10){
         $phone = "0123456789";
      }
     
   }else{
      $phone = "0123456789";
   }*/
   
   // $phone = substr($customer['default_address']['phone'], 2);
   $phone = preg_replace('/[^\dxX]/', '', $customer['default_address']['phone']);
   $username = substr($email, 0, strrpos($email, '@'));
   $password = "0123456789";
   $contact_zip = $customer['default_address']['zip'];
     
   $apiURL = 'https://www.creativemarketingincentives.biz/agencysubuserapi?apikey=f79a05af6fc7857438dc6b1fcaad0ad1';

   $fields = array(
      "first_name" => urlencode($first_name),               
      "last_name" => urlencode($last_name),
      "email" => $email,
      "phone" => urlencode($phone),
      "username" => urlencode($username),
      "password" => urlencode($password),
      "contact_zip"=> urlencode($contact_zip),
   );  


   $ch = curl_init();
   curl_setopt($ch,CURLOPT_URL, $apiURL);
   curl_setopt($ch,CURLOPT_POSTFIELDS, json_encode($fields));
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);  
   curl_setopt($ch, CURLOPT_TIMEOUT, 30);
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
   curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
   $response = curl_exec($ch );
   curl_close($ch);


} else {
   $response = 'there maybe something wrong in webhook';
}

$log = fopen('customer_log.txt' , 'a') or die ('Cant open the file');
fwrite($log, date("Y/m/d h:i:sa") . " " . $response . " [ First name: ". $first_name .", Last Name: ". $last_name.", Email: ". $email.", Phone: ". $phone." , Username: ". $username.", Password: ". $password.", Zip: ". $contact_zip. " ]".$data. "\n");
fclose($log);

?>